package edd.practica03;

/**
 *
 * @author 
 * @param <T>
 */
public class Celda<T> {
    
    /* Has uso del encapsulamiento */
    T valor;
    // siguiente;

    /**
     *
     * @return
     */
    @Override
    public String toString() {
        return null;
    }
    
}
