package edd.practica03;

/**
 *
 * @author 
 * @param <T>
 */
public class CeldaDoble<T> {
    
    /* Has uso del encapsulamiento */
    // valor;
    // anterior;
    CeldaDoble<T> siguiente;

    /**
     *
     * @return
     */
    @Override
    public String toString() {
        return null;
    }
}
