package edd.practica03;

/**
 * COMÉNTAME...
 * @author 
 * @param <T>
 */
public class ListaLigada<T> {
   
    //incluye  las variables de clase
    
    //incluye los métodos de la interfaz Lista
    
    /**
     * COMÉNTAME...
     * @param obj
     * @return
     */
    @Override
    public boolean equals(Object obj) {
        return false;
    }
}
